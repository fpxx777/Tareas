from config.db import connectToMySQL

class Colegios:
    def __init__(self, data):
        self.id = data["id"]
        self.nombre = data["nombre"]

    @classmethod
    def select_all(cls):
        query = "SELECT * FROM colegios"
        results = connectToMySQL('sist_educativo').query_db(query)
        colegios = []
        for colegio in results:
            colegios.append(cls(colegio))
        return colegios
        


    @classmethod
    def select_one(cls, id):
        query = f"SELECT * FROM colegios WHERE id = {id}"
        results = connectToMySQL('sist_educativo').query_db(query)
        colegios = []   
        for colegio in results:
            colegios.append(cls(colegio))
        return colegios
    
    @classmethod
    def insert(cls, nombre):
        query = f"INSERT INTO colegios (nombre) VALUES  ('{nombre}')"
        connectToMySQL('sist_educativo').query_db(query)
        
    @classmethod
    def update(cls, id, nombre):
        query = f"UPDATE colegios SET nombre='{nombre}' WHERE id={id}"
        result = connectToMySQL('sist_educativo').query_db(query)
        return result
    @classmethod
    def deleted(cls,id):
        query = f"DELETE FROM colegios WHERE id = {id}"
        result = connectToMySQL('sist_educativo').query_db(query)
        return result



class Cursos:
    def __init__(self, data):
        self.id = data["id"]
        self.nombre = data["name"]
        self.id_colegio = data["id_colegio"]

    @classmethod
    def select_all(cls):
        query = "SELECT * FROM cursos"
        results = connectToMySQL('sist_educativo').query_db(query)
        cursos = []
        for colegio in results:
            cursos.append(cls(colegio))
        return cursos
        


    @classmethod
    def select_one(cls, id):
        query = f"SELECT * FROM cursos WHERE id = {id}"
        results = connectToMySQL('sist_educativo').query_db(query)
        cursos = []
        for curso in results:
            cursos.append(cls(curso))
        return cursos
    
    @classmethod
    def insert(cls, nombre, colegio):
        query = f"INSERT INTO cursos (name, id_colegio) VALUES  ('{nombre}', {colegio})"
        connectToMySQL('sist_educativo').query_db(query)
    @classmethod
    def update(cls, id, nombre):
        query = f"UPDATE cursos SET name = '{nombre}' WHERE id = {id}"
        result = connectToMySQL('sist_educativo').query_db(query)
        return result
    @classmethod
    def deleted(cls,id):
        query = f"DELETE FROM cursos WHERE id = {id}"
        result = connectToMySQL('sist_educativo').query_db(query)
        return result



class Alumnos:
    def __init__(self, data):
        self.id = data["id"]
        self.nombre = data["nombre"]
        self.apellido = data["apellido"]
        self.id_curso = data["id_curso"]

    @classmethod
    def select_all(cls):
        query = "SELECT * FROM alumnos"
        results = connectToMySQL('sist_educativo').query_db(query)
        alumnos = []
        for alumno in results:
            alumnos.append(cls(alumno))
        return alumnos
        

    @classmethod
    def select_one(cls, id):
        query = f"SELECT * FROM alumnos WHERE id = {id}"
        results = connectToMySQL('sist_educativo').query_db(query)
        alumnos = []
        for alumno in results:
            alumnos.append(cls(alumno))
        return alumnos
    
    @classmethod
    def insert(cls, nombre, apellido, id_curso):
        query = f"INSERT INTO alumnos (nombre, apellido, id_curso) VALUES  ('{nombre}', '{apellido}', {id_curso})"
        connectToMySQL('sist_educativo').query_db(query)
    
    @classmethod
    def update(cls, id, nombre, apellido, id_curso):
        query = f"UPDATE alumnos SET nombre = '{nombre}', apellido = '{apellido}', id_curso={id_curso} WHERE id = {id}"
        result = connectToMySQL('sist_educativo').query_db(query)
        return result
    @classmethod
    def deleted(cls,id):
        query = f"DELETE FROM alumnos WHERE id = {id}"
        result = connectToMySQL('sist_educativo').query_db(query)
        return result


class Profesores:
    def __init__(self, data):
        self.id = data["id"]
        self.nombre = data["nombre"]
        self.apellido = data["apellido"]
        self.id_colegio = data["id_colegio"]

    @classmethod
    def select_all(cls):
        query = "SELECT * FROM profesores"
        results = connectToMySQL('sist_educativo').query_db(query)
        profesores = []
        for profesor in results:
            profesores.append(cls(profesor))
        return profesores
    
    @classmethod
    def insert(cls, nombre, apellido, id_colegio):
        query = f"INSERT INTO profesores (nombre, apellido, id_colegio) VALUES  ('{nombre}', '{apellido}', {id_colegio})"
        connectToMySQL('sist_educativo').query_db(query)
    
    @classmethod
    def select_one(cls, id):
        query = f"SELECT * FROM profesores WHERE id = {id}"
        results = connectToMySQL('sist_educativo').query_db(query)
        profesores = []
        for profesor in results:
            profesores.append(cls(profesor))
        return profesores
    @classmethod
    def update(cls, id, nombre, apellido, id_colegio):
        query = f"UPDATE profesores SET nombre = '{nombre}', apellido = '{apellido}', id_colegio={id_colegio} WHERE id = {id}"
        result = connectToMySQL('sist_educativo').query_db(query)
        return result
    @classmethod
    def deleted(cls,id):
        query = f"DELETE FROM profesores WHERE id = {id}"
        result = connectToMySQL('sist_educativo').query_db(query)
        return result