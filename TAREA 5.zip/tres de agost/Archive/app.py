from flask import Flask, render_template, request, redirect
from models.main import Colegios, Cursos,Alumnos, Profesores

app = Flask(__name__)

@app.route('/')
def main():
    colegios = Colegios.select_all()
    cursos = Cursos.select_all()
    alumnos = Alumnos.select_all()
    profesores = Profesores.select_all()
    return render_template('index.html', colegios=colegios, cursos=cursos, alumnos=alumnos, profesores=profesores)

@app.route('/colegios')
def colegios():
    colegios = Colegios.select_all()
    return render_template('colegios.html', colegios=colegios)



@app.route('/colegios/crear', methods = ["GET",])
def colegios_crear():
    return render_template('colegio_crear.html' )


@app.route('/colegios/crear', methods = ["POST",])
def crear_colegio():
    colegios = request.form['colegio']
    Colegios.insert(colegios)
    return redirect("/colegios")

@app.route('/colegios/<id_colegio>')
def one_colegios(id_colegio):
    colegio = Colegios.select_one(id_colegio)
    return render_template('colegio.html', colegio=colegio[0])

@app.route('/colegios/<id_colegios>/editar', methods = ["GET",])
def  editar_colegios(id_colegios):
    colegios = Colegios.select_one(id_colegios)
    return render_template('colegio_editar.html', colegios = colegios[0])

@app.route('/colegios/<id_colegio>/editar', methods=['POST'])
def editar_colegio(id_colegio):
    nombre = request.form.get("nombre_colegio")
    id = request.form.get("id_colegio")
    print(nombre, id)
    Colegios.update(id_colegio, nombre)
    return redirect("/colegios")

@app.route('/colegios/<id_colegio>/eliminar', methods=['POST'])
def eliminar_colegio(id_colegio):
    Colegios.deleted(id_colegio)
    return redirect('/colegios')



@app.route('/alumnos')
def alumnos():
    alumnos = Alumnos.select_all()
    return render_template('alumnos.html', alumnos=alumnos)

@app.route('/alumnos/crear', methods = ["GET",])
def alumnos_crear():
    cursos = Cursos.select_all()
    return render_template('crear_alumno.html', cursos=cursos)

@app.route('/alumnos/crear', methods = ["POST",])
def crear_alumnos():    
    nombre = request.form['nombre']
    apellido = request.form['apellido']
    id_curso = request.form['id_curso']
    Alumnos.insert(nombre, apellido, id_curso)
    return redirect('/alumnos')

@app.route('/alumnos/<id_alumnos>', methods = ["GET",])
def one_alumnos(id_alumnos):
    alumno = Alumnos.select_one(id_alumnos)
    return render_template('alumno.html', alumno=alumno[0])


@app.route('/alumnos/<id_alumnos>/editar', methods = ["GET",])
def update_alumnos(id_alumnos):
    alumno = Alumnos.select_one(id_alumnos)
    cursos = Cursos.select_all()
    return render_template('alumnos_editar.html', alumno=alumno[0], cursos=cursos)

@app.route('/alumnos/<id_alumnos>/editar', methods = ["POST",])
def update_alumno(id_alumnos):
    nombre = request.form['nombre_alumno']
    apellido = request.form['apellido_alumno']
    id_alumno = request.form['id_alumno']
    id_curso = request.form['id_curso']
    Alumnos.update(id_alumno, nombre, apellido, id_curso)
    return redirect("/alumnos")

@app.route("/alumnos/<id_alumnos>/eliminar", methods = ["POST",])
def eliminar_alumnoo(id_alumnos):
    Alumnos.deleted(id_alumnos)
    return redirect('/alumnos')

@app.route('/cursos')
def cursos():
    cursos = Cursos.select_all()
    return render_template('cursos.html', cursos=cursos)

@app.route('/cursos/crear', methods = ["GET",])
def cursos_crear():
    colegio = Colegios.select_all()
    return render_template('crear_curso.html', colegio=colegio)

@app.route('/cursos/crear', methods = ["POST",])
def crear_cursos():
    nombre = request.form['nombre']
    id_colegio = request.form['id_colegio']
    Cursos.insert(nombre,  id_colegio)
    return redirect("/cursos")

@app.route('/cursos/<id_curso>')
def one_cursos(id_curso):
    curso = Cursos.select_one(id_curso)
    return render_template('curso.html', curso=curso[0])


@app.route('/cursos/<id_curso>/editar',  methods = ["GET",])
def update_cursos(id_curso):
    curso = Cursos.select_one(id_curso)
    return render_template('cursos_editar.html', curso=curso[0])

@app.route('/cursos/<id_curso>/editar', methods = ["POST",])
def update_curso(id_curso):
    nombre = request.form['nombre_curso']
    id_curso= request.form['id_curso']
    Cursos.update(id_curso, nombre)
    return redirect("/cursos")

@app.route('/cursos/<id_curso>/eliminar', methods = ["POST",])
def eliminar_curso(id_curso):
    Cursos.deleted(id_curso)
    return redirect("/cursos")



@app.route('/profesores')
def profesores():
    profesores = Profesores.select_all()
    return render_template('profesores.html', profesores=profesores)


@app.route('/profesores/crear', methods = ["GET",])
def crear_profesores():
    colegios = Colegios.select_all()
    return render_template('crear_profesores.html', colegios=colegios)


@app.route('/profesores/crear', methods = ["POST",])
def profesores_crear():
    nombre = request.form['nombre']
    apellido = request.form['apellido']
    id_colegio = request.form['id_colegio']
    Profesores.insert(nombre, apellido, id_colegio)
    return redirect("/profesores")

@app.route('/profesores/<id_profesor>',  methods = ["GET",])
def one_profesor(id_profesor):
    profesor = Profesores.select_one(id_profesor)
    return render_template('profesor.html', profesor=profesor[0])

@app.route('/profesores/<id_profesor>/editar',  methods = ["GET",])
def update_profesor(id_profesor):
    profesor = Profesores.select_one(id_profesor)
    colegios = Colegios.select_all()
    return render_template('profesor_editar.html', profesor=profesor[0], colegios=colegios)



@app.route('/profesores/<id_profesor>/editar',  methods = ["POST",])
def update_profe(id_profesor):
    id_profe =request.form['id_profe']
    nombre = request.form['nombre_profesor']
    apellido = request.form['apellido_profesor']
    id_colegio = request.form['id_colegio']
    Profesores.update(id_profe, nombre, apellido, id_colegio)
    return redirect("/profesores")

@app.route("/profesores/<id_profesor>/elimnar",methods = ["POST",])
def elimiar_profesor(id_profesor):
    Profesores.deleted(id_profesor)
    return redirect("/profesores")



if __name__ == "__main__":
    app.run(debug=True)